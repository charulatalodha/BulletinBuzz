/** Automatically generated file. DO NOT MODIFY */
package com.example.bulletin_buzz;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}