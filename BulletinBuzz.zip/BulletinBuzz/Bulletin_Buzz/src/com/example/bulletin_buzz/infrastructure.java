package com.example.bulletin_buzz;

import android.app.Activity;
import android.os.Bundle;

public class infrastructure extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.page2);
		
	}
}
